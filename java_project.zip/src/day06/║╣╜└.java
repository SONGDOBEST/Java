package day06;

import java.util.Scanner;

public class 복습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* Scanner sc = new Scanner(System.in); */
//		String id = "test";
//		String pw = "1234";
//		
//		System.out.println("=====로그인=====");
//		System.out.print("아이디 입력> ");
//		String loginId = sc.next();
//		System.out.print("비밀번호 입력> ");
//		String loginPw = sc.next();
//		
//		if(id.equals(loginId) && pw.equals(loginPw)) {
//			System.out.println("로그인 성공");
//		}else if(!(id.equals(loginId)) && pw.equals(loginPw)) {
//			System.out.println("아이디가 틀렸습니다");
//		}else if(id.equals(loginId) && !(pw.equals(loginPw))) {
//			System.out.println("비밀번호가 틀렸습니다");
//		}else {
//			System.out.println("유효하지 않은 계정입니다");
//		}
//		
//		Scanner sc = new Scanner(System.in);
//		
//		int sum = 0;
//		for(int i=1; i<=100; i++) {
//			sum += i;
//		}
//		System.out.println(sum);
		
		int dan = 5;
		for(int i=1; i<20; i++) {
			System.out.println(dan+" * "+i+" = "+(dan*i));
		}
		
		
		
	}

}
