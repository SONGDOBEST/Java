package day04;

import java.util.Scanner;

public class Ex11_자습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String name = "";
		String id = "";
		String pw = "";
		
		while(true) {
			System.out.println("1.회원가입 2.로그인 3.종료");
			System.out.print("선택> ");
			int menu = sc.nextInt();
			
			if(menu == 1) {
				System.out.println("이름 입력");
				
			}
		}
	}

}
