package day01;

public class 타입_문자 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a = 'ㄱ';
		char b = 'ㄴ';
		System.out.println(a);
		System.out.println(b);
		System.out.println(a + b);
	}

}
