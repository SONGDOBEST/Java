package day01;

public class 타입_실수 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a = 10;
		double b = 3;
		double c = a + b;
		double d = a - b;
		double e = a * b;
		double f = a / b;
		double g = a % b;
		
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		
		
	}

}
