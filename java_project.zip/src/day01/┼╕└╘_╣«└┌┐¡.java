package day01;

public class 타입_문자열 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "홍길동";
		String b = "이순신";
		String c = "심청이";
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
//		System.out.println("a변수의 값은 : "+a);
//		System.out.println("b변수의 값은 : "+b);
//		System.out.println("c변수의 값은 : "+c);
		
		char aa = 'a';
		char bb = 'b';
		char cc = 'c';
		
		System.out.println(aa+"변수의 값은 : "+a);
		System.out.println(bb+"변수의 값은 : "+b);
		System.out.println(cc+"변수의 값은 : "+c);
		// 출력예시
//		a변수의 값은 : 홍길동
//		b변수의 값은 : 이순신
//		c변수의 값은 : 심청이

//		System.out.println(a +" "+ b +" "+ c);
		
		
	}

}
