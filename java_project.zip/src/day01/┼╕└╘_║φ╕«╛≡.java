package day01;

public class 타입_블리언 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean a = true;
		boolean b = false;
		System.out.println(a);
		System.out.println(b);
		
		int aa = 10;
		int bb = 20;
		boolean c = aa > bb;
		System.out.println(c);
		
	}

}
