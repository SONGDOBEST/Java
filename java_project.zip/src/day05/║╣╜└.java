package day05;

import java.util.Scanner;

public class 복습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("숫자 입력> ");
		int num = sc.nextInt();
		int sum = 0;
		
		for(int i=1; i<=num; i++) {
			sum += i;
		}
		System.out.println(sum);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		if(num % 15 == 0) {
//			System.out.println("3과 5의 배수");
//		}else if(num % 3 == 0) {
//			System.out.println("3의 배수");
//		}else if(num % 5 == 0) {
//			System.out.println("5의 배수");
//		}else {
//			System.out.println("둘 다 아님");
//		}
		
		
		
	}

}
