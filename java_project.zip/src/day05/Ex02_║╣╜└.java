package day05;

public class Ex02_복습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
